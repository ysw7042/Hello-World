package basic;

public class HelloWorld {
	public static void main(String[] args) {
		System.out.print("Hello,");
		System.out.println("World!!!");
		System.out.println("�ȳ�, �ڹ�!!!");
	}	
}